Laboratorio 4 - Matematica Computacional

Grupo no: 2

Nome do ficheiro do relatório: 'relatório.m'