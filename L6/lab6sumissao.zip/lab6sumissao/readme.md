Lab6

Ficheiro principal: repostas.m