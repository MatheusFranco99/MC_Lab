# Lab 5 entrega

Ficheiro principal: respostas.m