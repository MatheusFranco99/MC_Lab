% Exercicio 1 - ver ex1.m

% Exercicio 2 - ver ex2.m

% Exercicio 3 - ver ex3.m

% Exercicio 4

>> [a,it] = ex3([1,-5,-0.5],10^-10)

a =

   1.982148066134256  -4.981737090763945  -0.503305599641024


it =

     5

% Exercicio 5 - ver ex5.m, ex5_grafico.pdf

>> [soma] = ex5(ti,xi,1.982148066134256,  -4.981737090763945,  -0.503305599641024)

soma =

     1.689007550024331e-07
    
% No grafico, os pontos referem-se aos valores da tabela. Observamos que a solucao g
% encontrada ajusta-se bem aos valores da tabela, o que tambem e possivel
% ser concluido pela soma dos quadrados dos desvios, que e da ordem de 10^-7.
     
