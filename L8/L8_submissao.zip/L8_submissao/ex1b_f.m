function [f] = ex1b_f()
f = @(x)10.*x.^2.*exp(-x) - 1;
end
