Grupo No. 02.

Membros:
Beatriz Canaverde 95736
Catarina Carvalho 95738
Mónica Abreu 93312
Matheus Franco 92523


Ler primeiro o ficheiro 'repostas'.